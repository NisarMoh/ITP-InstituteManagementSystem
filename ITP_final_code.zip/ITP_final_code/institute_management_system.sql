-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 06, 2019 at 05:45 PM
-- Server version: 10.3.15-MariaDB
-- PHP Version: 7.3.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `institute_management_system`
--

-- --------------------------------------------------------

--
-- Table structure for table `assessment`
--

CREATE TABLE `assessment` (
  `AssessmentID` char(7) NOT NULL,
  `Evaluation_type` char(4) NOT NULL,
  `Assessment_title` varchar(100) NOT NULL,
  `Subject` char(7) NOT NULL,
  `Classroom` char(7) NOT NULL,
  `DateTime` datetime NOT NULL,
  `TimeStamp` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `assessment`
--

INSERT INTO `assessment` (`AssessmentID`, `Evaluation_type`, `Assessment_title`, `Subject`, `Classroom`, `DateTime`, `TimeStamp`) VALUES
('ASM0001', 'exam', 'asdasd', '1', '9', '2019-01-01 01:00:00', '2019-09-06 06:34:49');

--
-- Triggers `assessment`
--
DELIMITER $$
CREATE TRIGGER `assessment1_ass` BEFORE INSERT ON `assessment` FOR EACH ROW BEGIN
  INSERT INTO assessment1 VALUES (NULL);
  SET NEW.AssessmentID = CONCAT('ASM', LPAD(LAST_INSERT_ID(), 4, '0'));
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `assessment1`
--

CREATE TABLE `assessment1` (
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `assessment1`
--

INSERT INTO `assessment1` (`id`) VALUES
(1),
(2);

-- --------------------------------------------------------

--
-- Table structure for table `classroom`
--

CREATE TABLE `classroom` (
  `hall_id` int(11) NOT NULL,
  `classroom` varchar(20) NOT NULL,
  `building` varchar(20) NOT NULL,
  `number_of_seats` int(4) NOT NULL,
  `floor` int(2) NOT NULL,
  `multimedia` char(4) NOT NULL,
  `air_condition` char(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `classroom`
--

INSERT INTO `classroom` (`hall_id`, `classroom`, `building`, `number_of_seats`, `floor`, `multimedia`, `air_condition`) VALUES
(9, 'A506', 'Main', 150, 5, 'YES', 'YES'),
(10, 'A503', 'Main', 100, 5, 'NO', 'YES'),
(11, '502', 'New Building', 120, 5, 'NO', 'YES'),
(12, 'A302', 'Main', 60, 3, 'YES', 'NO');

-- --------------------------------------------------------

--
-- Table structure for table `forum_category`
--

CREATE TABLE `forum_category` (
  `category_id` int(11) NOT NULL,
  `category_name` varchar(45) NOT NULL,
  `category_description` varchar(128) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `forum_category`
--

INSERT INTO `forum_category` (`category_id`, `category_name`, `category_description`) VALUES
(1, 'Other', 'All topics that don\'t belong in any other categories go here.'),
(2, 'Programming', 'Who want to learn quickly?'),
(3, 'Maths', 'A board only for maths related topics...'),
(4, 'Science', 'A Category for all science related topics...'),
(5, 'Sports', 'All outdoor and indoor sports topics go here...'),
(6, 'Commerce', 'only for commerce related topics');

-- --------------------------------------------------------

--
-- Table structure for table `forum_post`
--

CREATE TABLE `forum_post` (
  `post_id` bigint(20) NOT NULL,
  `post_text` varchar(2048) NOT NULL,
  `post_date` date NOT NULL DEFAULT curdate(),
  `post_time` time NOT NULL DEFAULT curtime(),
  `post_poster_id` varchar(8) NOT NULL,
  `post_topic_id` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `forum_post`
--

INSERT INTO `forum_post` (`post_id`, `post_text`, `post_date`, `post_time`, `post_poster_id`, `post_topic_id`) VALUES
(6, 'TIme and date, please ?', '2019-09-06', '11:06:30', 'STD0003', 5),
(7, 'Learn to google, you piece of crap.', '2019-09-06', '11:07:34', 'STD0003', 4);

-- --------------------------------------------------------

--
-- Table structure for table `forum_topic`
--

CREATE TABLE `forum_topic` (
  `topic_id` bigint(20) NOT NULL,
  `topic_text` varchar(256) NOT NULL,
  `topic_date` date NOT NULL DEFAULT curdate(),
  `topic_time` time NOT NULL DEFAULT curtime(),
  `topic_op_id` varchar(8) NOT NULL,
  `topic_category_id` int(11) NOT NULL,
  `topic_description` varchar(4096) DEFAULT NULL,
  `topic_visit_counter` bigint(20) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `forum_topic`
--

INSERT INTO `forum_topic` (`topic_id`, `topic_text`, `topic_date`, `topic_time`, `topic_op_id`, `topic_category_id`, `topic_description`, `topic_visit_counter`) VALUES
(3, '[Guide] Exam Tips', '2019-09-06', '10:55:22', 'STD0002', 1, 'This is a guide on how to prepare to an exam\r\n1. Study\r\n2. Study\r\n3. Make a plan\r\n4. Avoid distractions\r\n5. Organize your study spac\r\n7. Do past papers\r\n.\r\n.\r\n.\r\nn. Study Hard', 11),
(4, '[OOP] How to define a final variable in C++ ?', '2019-09-06', '10:57:39', 'STD0002', 2, 'Guys,\r\nI need to initialize and define a variable that cannot be changed.\r\nDoes anyone know how to define a static variable ?\r\n\r\nThank you.', 4),
(5, '[Football] Anyone interested in a friendly match ?', '2019-09-06', '11:04:16', 'STD0002', 1, 'The football club has decided to hold a friendly football tournament.\r\nEveryone is allowed to play. A team has to have a minimum 7 players.\r\nFor details contact me. \r\nIf you have any doubts comment below...', 3);

-- --------------------------------------------------------

--
-- Table structure for table `online_assessment`
--

CREATE TABLE `online_assessment` (
  `AssessmentID` char(7) NOT NULL,
  `Duration` int(11) NOT NULL,
  `Review` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `online_assessment`
--

INSERT INTO `online_assessment` (`AssessmentID`, `Duration`, `Review`) VALUES
('ASM0001', 15, 0),
('ASM0002', 60, 0);

-- --------------------------------------------------------

--
-- Table structure for table `staff`
--

CREATE TABLE `staff` (
  `Staff_ID` varchar(7) NOT NULL DEFAULT '0',
  `NIC` varchar(50) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `User_Name` varchar(50) NOT NULL,
  `Full_Name` varchar(100) NOT NULL,
  `Last_Name` varchar(100) NOT NULL,
  `Password` varchar(50) NOT NULL,
  `Qualification` varchar(250) NOT NULL,
  `Salary` int(10) DEFAULT NULL,
  `Ethnic` varchar(20) NOT NULL,
  `Religion` varchar(20) NOT NULL,
  `Civil_Status` varchar(20) NOT NULL,
  `Address` varchar(250) NOT NULL,
  `Gender` varchar(6) NOT NULL,
  `DateOfBirth` date NOT NULL,
  `Phone_Number` int(20) NOT NULL,
  `Administrator` varchar(6) DEFAULT NULL,
  `Tutor` varchar(6) DEFAULT NULL,
  `Cashier` varchar(6) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `staff`
--

INSERT INTO `staff` (`Staff_ID`, `NIC`, `Email`, `User_Name`, `Full_Name`, `Last_Name`, `Password`, `Qualification`, `Salary`, `Ethnic`, `Religion`, `Civil_Status`, `Address`, `Gender`, `DateOfBirth`, `Phone_Number`, `Administrator`, `Tutor`, `Cashier`) VALUES
('STF0001', 'adminV', 'admin@admin.com', 'admin', 'admin', 'admin', '21232f297a57a5a743894a0e4a801fc3', 'admin', 2147483647, 'Others', 'Christian', 'married', 'admin', 'Male', '2019-10-02', 6276276, 'True', 'True', 'False'),
('STF0007', '123456789V', 'zuraij@gmail.com', 'TheLegend', 'Zuraij', 'Majeed', '81dc9bdb52d04dc20036dbd8313ed055', 'Software Engineer', 2147483647, 'Muslim', 'Muslim', 'single', 'California', 'Male', '1998-11-25', 776103254, 'false', 'True', 'false'),
('STF0008', '965562627V', 'Pirathi@gmail.com', 'Pirathi', 'Pirathi ', 'karan', '81dc9bdb52d04dc20036dbd8313ed055', 'Software Engineer', 3422, 'Tamil', 'Christian', 'married', 'point pedro,jaffna,srilanka', 'Male', '2019-09-04', 776103254, 'False', 'False', 'True'),
('STF0009', '267167821V', 'ghashga@gmail.com', 'Rangitha', 'rangith', 'ghgh', '81dc9bdb52d04dc20036dbd8313ed055', 'hsggs', 251652, 'Sinhalese', 'Christian', 'married', 'point pedro,jaffna,srilanka', 'Male', '2019-09-10', 776103254, 'True', 'True', 'False'),
('STF0010', '26266v', 'asssa@gmal.com', 'sara11', 'sfgfs', 'hdhg', '81dc9bdb52d04dc20036dbd8313ed055', 'qfsf', 2124154, 'Tamil', 'Christian', 'married', 'point pedro,jaffna,srilanka', 'Male', '2019-09-04', 776103254, 'False', 'True', 'False');

--
-- Triggers `staff`
--
DELIMITER $$
CREATE TRIGGER `staff1_staff` BEFORE INSERT ON `staff` FOR EACH ROW BEGIN
  INSERT INTO staff1 VALUES (NULL);
  SET NEW.Staff_ID = CONCAT('STF', LPAD(LAST_INSERT_ID(), 4, '0'));
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `staff1`
--

CREATE TABLE `staff1` (
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `staff1`
--

INSERT INTO `staff1` (`id`) VALUES
(1),
(2),
(3),
(4),
(5),
(6),
(7),
(8),
(9),
(10);

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `id` varchar(7) NOT NULL DEFAULT '0',
  `username` varchar(50) NOT NULL,
  `password` varchar(100) NOT NULL,
  `firstname` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  `gender` varchar(50) DEFAULT NULL,
  `age` int(100) NOT NULL,
  `contactno` int(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `address` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`id`, `username`, `password`, `firstname`, `lastname`, `gender`, `age`, `contactno`, `email`, `address`) VALUES
('STD0001', 'Student2', '03a6a0da987379dddf22b98aad899762', 'Student123', 'Student', 'female', 17, 779860610, 'student@student.com', 'Malabe'),
('STD0002', 'Pirathi', '81dc9bdb52d04dc20036dbd8313ed055', 'Pirathi', 'karan', 'female', 12, 779860610, 'sss@ss.com', 'point pedro,jaffna,srilanka'),
('STD0005', 'student123', '81dc9bdb52d04dc20036dbd8313ed055', 'student', 'student', 'male', 12, 779860610, 'gdhaghs@fam.com', 'point pedro,jaffna,srilanka'),
('STD0006', 'sara', '81dc9bdb52d04dc20036dbd8313ed055', 'Sarangan', 'sakthi', 'female', 8997, 890898, 'admin@admin.com', 'chilaw');

--
-- Triggers `student`
--
DELIMITER $$
CREATE TRIGGER `student1_student` BEFORE INSERT ON `student` FOR EACH ROW BEGIN
  INSERT INTO student1 VALUES (NULL);
  SET NEW.id= CONCAT('STD', LPAD(LAST_INSERT_ID(), 4, '0'));
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `student1`
--

CREATE TABLE `student1` (
  `StudentID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student1`
--

INSERT INTO `student1` (`StudentID`) VALUES
(1),
(2),
(3),
(4),
(5),
(6);

-- --------------------------------------------------------

--
-- Table structure for table `student_assignment`
--

CREATE TABLE `student_assignment` (
  `StudentID` varchar(80) NOT NULL,
  `FileName` varchar(80) NOT NULL,
  `SubjectID` int(80) NOT NULL,
  `assignment_directory` varchar(80) NOT NULL,
  `Date_Time` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student_assignment`
--

INSERT INTO `student_assignment` (`StudentID`, `FileName`, `SubjectID`, `assignment_directory`, `Date_Time`) VALUES
('STD0001', 'Math', 1, 'ABC.rar', '2019-09-27 08:13:13'),
('STD0001', 'SE', 2, 'DOC-20190612-WA0002.pdf', '2019-09-28 06:12:11');

-- --------------------------------------------------------

--
-- Table structure for table `subject`
--

CREATE TABLE `subject` (
  `sub_id` int(11) NOT NULL,
  `subject` varchar(100) NOT NULL,
  `reference` varchar(1000) NOT NULL,
  `decription` varchar(1000) NOT NULL,
  `amount` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `subject`
--

INSERT INTO `subject` (`sub_id`, `subject`, `reference`, `decription`, `amount`) VALUES
(1, 'Maths', 'Algebra 1', 'Advance maths', '2000'),
(2, 'SE', 'Software enginnering', 'lesson 1', '1000'),
(3, 'OOP', 'Stackoverflow', 'Dummy OOP Guide', '3000'),
(4, 'Science', 'Bio.org', 'Introduction to biology', '1000'),
(5, 'SPM', 'Repl.it', 'Activity diagram', '2000');

-- --------------------------------------------------------

--
-- Table structure for table `timetable`
--

CREATE TABLE `timetable` (
  `timetable_id` varchar(50) NOT NULL,
  `hall_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `timetable`
--

INSERT INTO `timetable` (`timetable_id`, `hall_name`) VALUES
('A402', 'A402'),
('A502', 'A502'),
('A503', 'A503'),
('A506', 'A506');

-- --------------------------------------------------------

--
-- Table structure for table `timetable_staff_subject`
--

CREATE TABLE `timetable_staff_subject` (
  `tid` varchar(50) NOT NULL,
  `staff_name` varchar(50) DEFAULT NULL,
  `subject_name` varchar(50) DEFAULT NULL,
  `day` int(11) NOT NULL,
  `start_time` int(11) NOT NULL,
  `end_time` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `timetable_staff_subject`
--

INSERT INTO `timetable_staff_subject` (`tid`, `staff_name`, `subject_name`, `day`, `start_time`, `end_time`) VALUES
('A402', '', '', 1, 8, 9),
('A402', '', '', 1, 9, 10),
('A402', '', '', 1, 10, 11),
('A402', '', '', 1, 11, 12),
('A402', '', '', 1, 12, 13),
('A402', '', '', 1, 13, 14),
('A402', '', '', 1, 14, 15),
('A402', '', '', 1, 15, 16),
('A402', '', '', 1, 16, 17),
('A402', 'Namal', 'SE', 2, 8, 9),
('A402', '', '', 2, 9, 10),
('A402', '', '', 2, 10, 11),
('A402', '', '', 2, 11, 12),
('A402', '', '', 2, 12, 13),
('A402', '', '', 2, 13, 14),
('A402', '', '', 2, 14, 15),
('A402', '', '', 2, 15, 16),
('A402', '', '', 2, 16, 17),
('A402', '', '', 3, 8, 9),
('A402', '', '', 3, 9, 10),
('A402', '', '', 3, 10, 11),
('A402', '', '', 3, 11, 12),
('A402', '', '', 3, 12, 13),
('A402', '', '', 3, 13, 14),
('A402', '', '', 3, 14, 15),
('A402', '', '', 3, 15, 16),
('A402', '', '', 3, 16, 17),
('A402', '', '', 4, 8, 9),
('A402', '', '', 4, 9, 10),
('A402', '', '', 4, 10, 11),
('A402', '', '', 4, 11, 12),
('A402', '', '', 4, 12, 13),
('A402', '', '', 4, 13, 14),
('A402', '', '', 4, 14, 15),
('A402', '', '', 4, 15, 16),
('A402', '', '', 4, 16, 17),
('A402', '', '', 5, 8, 9),
('A402', '', '', 5, 9, 10),
('A402', '', '', 5, 10, 11),
('A402', '', '', 5, 11, 12),
('A402', '', '', 5, 12, 13),
('A402', '', '', 5, 13, 14),
('A402', '', '', 5, 14, 15),
('A402', '', '', 5, 15, 16),
('A402', '', '', 5, 16, 17),
('A402', '', '', 6, 8, 9),
('A402', '', '', 6, 9, 10),
('A402', '', '', 6, 10, 11),
('A402', '', '', 6, 11, 12),
('A402', '', '', 6, 12, 13),
('A402', '', '', 6, 13, 14),
('A402', '', '', 6, 14, 15),
('A402', '', '', 6, 15, 16),
('A402', '', '', 6, 16, 17),
('A402', '', '', 7, 8, 9),
('A402', '', '', 7, 9, 10),
('A402', '', '', 7, 10, 11),
('A402', '', '', 7, 11, 12),
('A402', '', '', 7, 12, 13),
('A402', '', '', 7, 13, 14),
('A402', '', '', 7, 14, 15),
('A402', '', '', 7, 15, 16),
('A402', '', '', 7, 16, 17),
('A502', 'Qwen', 'SPM', 1, 8, 9),
('A502', '', '', 1, 9, 10),
('A502', '', '', 1, 10, 11),
('A502', '', '', 1, 11, 12),
('A502', '', '', 1, 12, 13),
('A502', '', '', 1, 13, 14),
('A502', '', '', 1, 14, 15),
('A502', '', '', 1, 15, 16),
('A502', '', '', 1, 16, 17),
('A502', 'Malith', 'OOP', 2, 8, 9),
('A502', '', '', 2, 9, 10),
('A502', '', '', 2, 10, 11),
('A502', '', '', 2, 11, 12),
('A502', '', '', 2, 12, 13),
('A502', '', '', 2, 13, 14),
('A502', '', '', 2, 14, 15),
('A502', '', '', 2, 15, 16),
('A502', '', '', 2, 16, 17),
('A502', '', '', 3, 8, 9),
('A502', '', '', 3, 9, 10),
('A502', 'Manitha', 'SE', 3, 10, 11),
('A502', '', '', 3, 11, 12),
('A502', '', '', 3, 12, 13),
('A502', '', '', 3, 13, 14),
('A502', '', '', 3, 14, 15),
('A502', '', '', 3, 15, 16),
('A502', '', '', 3, 16, 17),
('A502', '', '', 4, 8, 9),
('A502', '', '', 4, 9, 10),
('A502', '', '', 4, 10, 11),
('A502', '', '', 4, 11, 12),
('A502', '', '', 4, 12, 13),
('A502', '', '', 4, 13, 14),
('A502', '', '', 4, 14, 15),
('A502', '', '', 4, 15, 16),
('A502', '', '', 4, 16, 17),
('A502', '', '', 5, 8, 9),
('A502', '', '', 5, 9, 10),
('A502', '', '', 5, 10, 11),
('A502', '', '', 5, 11, 12),
('A502', '', '', 5, 12, 13),
('A502', '', '', 5, 13, 14),
('A502', '', '', 5, 14, 15),
('A502', '', '', 5, 15, 16),
('A502', '', '', 5, 16, 17),
('A502', '', '', 6, 8, 9),
('A502', '', '', 6, 9, 10),
('A502', '', '', 6, 10, 11),
('A502', '', '', 6, 11, 12),
('A502', '', '', 6, 12, 13),
('A502', '', '', 6, 13, 14),
('A502', '', '', 6, 14, 15),
('A502', '', '', 6, 15, 16),
('A502', '', '', 6, 16, 17),
('A502', '', '', 7, 8, 9),
('A502', '', '', 7, 9, 10),
('A502', '', '', 7, 10, 11),
('A502', '', '', 7, 11, 12),
('A502', '', '', 7, 12, 13),
('A502', '', '', 7, 13, 14),
('A502', '', '', 7, 14, 15),
('A502', '', '', 7, 15, 16),
('A502', '', '', 7, 16, 17),
('A503', '', '', 1, 8, 9),
('A503', '', '', 1, 9, 10),
('A503', '', '', 1, 10, 11),
('A503', '', '', 1, 11, 12),
('A503', '', '', 1, 12, 13),
('A503', '', '', 1, 13, 14),
('A503', '', '', 1, 14, 15),
('A503', '', '', 1, 15, 16),
('A503', '', '', 1, 16, 17),
('A503', 'Yamith', 'SPM', 2, 8, 9),
('A503', '', '', 2, 9, 10),
('A503', '', '', 2, 10, 11),
('A503', '', '', 2, 11, 12),
('A503', '', '', 2, 12, 13),
('A503', '', '', 2, 13, 14),
('A503', '', '', 2, 14, 15),
('A503', '', '', 2, 15, 16),
('A503', '', '', 2, 16, 17),
('A503', '', '', 3, 8, 9),
('A503', '', '', 3, 9, 10),
('A503', '', '', 3, 10, 11),
('A503', '', '', 3, 11, 12),
('A503', '', '', 3, 12, 13),
('A503', '', '', 3, 13, 14),
('A503', '', '', 3, 14, 15),
('A503', '', '', 3, 15, 16),
('A503', '', '', 3, 16, 17),
('A503', '', '', 4, 8, 9),
('A503', '', '', 4, 9, 10),
('A503', 'Jehan', 'Science', 4, 10, 11),
('A503', '', '', 4, 11, 12),
('A503', '', '', 4, 12, 13),
('A503', '', '', 4, 13, 14),
('A503', 'Roshen', 'Bio', 4, 14, 15),
('A503', '', '', 4, 15, 16),
('A503', '', '', 4, 16, 17),
('A503', '', '', 5, 8, 9),
('A503', '', '', 5, 9, 10),
('A503', '', '', 5, 10, 11),
('A503', '', '', 5, 11, 12),
('A503', '', '', 5, 12, 13),
('A503', '', '', 5, 13, 14),
('A503', '', '', 5, 14, 15),
('A503', '', '', 5, 15, 16),
('A503', '', '', 5, 16, 17),
('A503', '', '', 6, 8, 9),
('A503', '', '', 6, 9, 10),
('A503', '', '', 6, 10, 11),
('A503', '', '', 6, 11, 12),
('A503', '', '', 6, 12, 13),
('A503', '', '', 6, 13, 14),
('A503', '', '', 6, 14, 15),
('A503', '', '', 6, 15, 16),
('A503', '', '', 6, 16, 17),
('A503', '', '', 7, 8, 9),
('A503', '', '', 7, 9, 10),
('A503', '', '', 7, 10, 11),
('A503', '', '', 7, 11, 12),
('A503', '', '', 7, 12, 13),
('A503', '', '', 7, 13, 14),
('A503', '', '', 7, 14, 15),
('A503', '', '', 7, 15, 16),
('A503', '', '', 7, 16, 17),
('A506', 'Namal', 'OOP', 1, 8, 9),
('A506', '', '', 1, 9, 10),
('A506', '', '', 1, 10, 11),
('A506', '', '', 1, 11, 12),
('A506', '', '', 1, 12, 13),
('A506', '', '', 1, 13, 14),
('A506', '', '', 1, 14, 15),
('A506', '', '', 1, 15, 16),
('A506', '', '', 1, 16, 17),
('A506', '', '', 2, 8, 9),
('A506', '', '', 2, 9, 10),
('A506', '', '', 2, 10, 11),
('A506', '', '', 2, 11, 12),
('A506', '', '', 2, 12, 13),
('A506', '', '', 2, 13, 14),
('A506', '', '', 2, 14, 15),
('A506', '', '', 2, 15, 16),
('A506', '', '', 2, 16, 17),
('A506', 'Malith', 'SE', 3, 8, 9),
('A506', '', '', 3, 9, 10),
('A506', '', '', 3, 10, 11),
('A506', '', '', 3, 11, 12),
('A506', '', '', 3, 12, 13),
('A506', '', '', 3, 13, 14),
('A506', '', '', 3, 14, 15),
('A506', '', '', 3, 15, 16),
('A506', '', '', 3, 16, 17),
('A506', '', '', 4, 8, 9),
('A506', '', '', 4, 9, 10),
('A506', '', '', 4, 10, 11),
('A506', '', '', 4, 11, 12),
('A506', 'Jay', 'SPM', 4, 12, 13),
('A506', '', '', 4, 13, 14),
('A506', '', '', 4, 14, 15),
('A506', '', '', 4, 15, 16),
('A506', '', '', 4, 16, 17),
('A506', '', '', 5, 8, 9),
('A506', '', '', 5, 9, 10),
('A506', 'Kumara', 'OOP', 5, 10, 11),
('A506', '', '', 5, 11, 12),
('A506', '', '', 5, 12, 13),
('A506', '', '', 5, 13, 14),
('A506', '', '', 5, 14, 15),
('A506', '', '', 5, 15, 16),
('A506', '', '', 5, 16, 17),
('A506', '', '', 6, 8, 9),
('A506', '', '', 6, 9, 10),
('A506', '', '', 6, 10, 11),
('A506', '', '', 6, 11, 12),
('A506', '', '', 6, 12, 13),
('A506', '', '', 6, 13, 14),
('A506', '', '', 6, 14, 15),
('A506', '', '', 6, 15, 16),
('A506', '', '', 6, 16, 17),
('A506', '', '', 7, 8, 9),
('A506', '', '', 7, 9, 10),
('A506', '', '', 7, 10, 11),
('A506', '', '', 7, 11, 12),
('A506', '', '', 7, 12, 13),
('A506', '', '', 7, 13, 14),
('A506', '', '', 7, 14, 15),
('A506', '', '', 7, 15, 16),
('A506', '', '', 7, 16, 17);

-- --------------------------------------------------------

--
-- Table structure for table `tutor_materials`
--

CREATE TABLE `tutor_materials` (
  `Staff_ID` varchar(80) NOT NULL,
  `FileName` varchar(80) NOT NULL,
  `SubjectID` int(80) NOT NULL,
  `materials_directory` varchar(80) NOT NULL,
  `Date_Time` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tutor_materials`
--

INSERT INTO `tutor_materials` (`Staff_ID`, `FileName`, `SubjectID`, `materials_directory`, `Date_Time`) VALUES
('STF0001', 'IOT_01', 1, 'angular-7-for-beginners.pdf', '2019-09-06 09:52:42'),
('STF0001', 'IOT_9988', 4, 'DOC-20190612-WA0002.pdf', '2019-09-06 01:36:43'),
('STF0001', 'OOP_6666', 2, 'IT2030 - OOP - Paper 1a.pdf', '2019-09-06 11:20:54');

-- --------------------------------------------------------

--
-- Table structure for table `written_assessment`
--

CREATE TABLE `written_assessment` (
  `AssessmentID` char(7) NOT NULL,
  `Marked_by` char(7) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `assessment`
--
ALTER TABLE `assessment`
  ADD PRIMARY KEY (`AssessmentID`);

--
-- Indexes for table `assessment1`
--
ALTER TABLE `assessment1`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `classroom`
--
ALTER TABLE `classroom`
  ADD PRIMARY KEY (`hall_id`);

--
-- Indexes for table `forum_category`
--
ALTER TABLE `forum_category`
  ADD PRIMARY KEY (`category_id`),
  ADD UNIQUE KEY `category_name_UNIQUE` (`category_name`),
  ADD UNIQUE KEY `category_id_UNIQUE` (`category_id`);

--
-- Indexes for table `forum_post`
--
ALTER TABLE `forum_post`
  ADD PRIMARY KEY (`post_id`),
  ADD UNIQUE KEY `post_id_UNIQUE` (`post_id`),
  ADD KEY `post_topic_id_fk` (`post_topic_id`);

--
-- Indexes for table `forum_topic`
--
ALTER TABLE `forum_topic`
  ADD PRIMARY KEY (`topic_id`),
  ADD UNIQUE KEY `topic_id_UNIQUE` (`topic_id`),
  ADD KEY `topic_category_id_idx` (`topic_category_id`);

--
-- Indexes for table `online_assessment`
--
ALTER TABLE `online_assessment`
  ADD PRIMARY KEY (`AssessmentID`);

--
-- Indexes for table `staff`
--
ALTER TABLE `staff`
  ADD PRIMARY KEY (`Staff_ID`),
  ADD UNIQUE KEY `NIC` (`NIC`);

--
-- Indexes for table `staff1`
--
ALTER TABLE `staff1`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `student1`
--
ALTER TABLE `student1`
  ADD PRIMARY KEY (`StudentID`);

--
-- Indexes for table `student_assignment`
--
ALTER TABLE `student_assignment`
  ADD PRIMARY KEY (`StudentID`,`FileName`),
  ADD KEY `SubjectID` (`SubjectID`),
  ADD KEY `StudentID` (`StudentID`);

--
-- Indexes for table `subject`
--
ALTER TABLE `subject`
  ADD PRIMARY KEY (`sub_id`);

--
-- Indexes for table `timetable`
--
ALTER TABLE `timetable`
  ADD PRIMARY KEY (`timetable_id`);

--
-- Indexes for table `timetable_staff_subject`
--
ALTER TABLE `timetable_staff_subject`
  ADD PRIMARY KEY (`tid`,`day`,`start_time`,`end_time`);

--
-- Indexes for table `tutor_materials`
--
ALTER TABLE `tutor_materials`
  ADD PRIMARY KEY (`Staff_ID`,`FileName`),
  ADD KEY `SubjectID` (`SubjectID`),
  ADD KEY `Staff_ID` (`Staff_ID`);

--
-- Indexes for table `written_assessment`
--
ALTER TABLE `written_assessment`
  ADD PRIMARY KEY (`AssessmentID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `assessment1`
--
ALTER TABLE `assessment1`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `classroom`
--
ALTER TABLE `classroom`
  MODIFY `hall_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `forum_category`
--
ALTER TABLE `forum_category`
  MODIFY `category_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `forum_post`
--
ALTER TABLE `forum_post`
  MODIFY `post_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `forum_topic`
--
ALTER TABLE `forum_topic`
  MODIFY `topic_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `staff1`
--
ALTER TABLE `staff1`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `student1`
--
ALTER TABLE `student1`
  MODIFY `StudentID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `subject`
--
ALTER TABLE `subject`
  MODIFY `sub_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `forum_post`
--
ALTER TABLE `forum_post`
  ADD CONSTRAINT `post_topic_id_fk` FOREIGN KEY (`post_topic_id`) REFERENCES `forum_topic` (`topic_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `forum_topic`
--
ALTER TABLE `forum_topic`
  ADD CONSTRAINT `topic_category_id` FOREIGN KEY (`topic_category_id`) REFERENCES `forum_category` (`category_id`);

--
-- Constraints for table `student_assignment`
--
ALTER TABLE `student_assignment`
  ADD CONSTRAINT `student_assignment_ibfk_1` FOREIGN KEY (`StudentID`) REFERENCES `student` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `timetable_staff_subject`
--
ALTER TABLE `timetable_staff_subject`
  ADD CONSTRAINT `fk_timetable` FOREIGN KEY (`tid`) REFERENCES `timetable` (`timetable_id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Constraints for table `tutor_materials`
--
ALTER TABLE `tutor_materials`
  ADD CONSTRAINT `tutor_materials_ibfk_1` FOREIGN KEY (`Staff_ID`) REFERENCES `staff` (`Staff_ID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tutor_materials_ibfk_2` FOREIGN KEY (`SubjectID`) REFERENCES `subject` (`sub_id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
